'use client';

import { useState, useEffect, useRef, useCallback } from 'react';

// Types
interface SleepSession {
  date: string;
  duration: number; // in seconds
  quality: number; // 1-5 rating
  location: string;
}

interface UserStats {
  totalSessions: number;
  totalSleepTime: number;
  averageQuality: number;
  longestSession: number;
  weeklyGoal: number; // hours
  weeklyProgress: number; // hours
}

interface ServerLocation {
  value: string;
  label: string;
  country: string;
  continent: string;
  coordinates: [number, number]; // [lat, lng]
  load: number; // 0-100%
}

export default function Home() {
  const [currentTime, setCurrentTime] = useState('');
  const [activeSleepers, setActiveSleepers] = useState(0);
  const [currentScreen, setCurrentScreen] = useState('main');
  const [username, setUsername] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('Berlin');
  const [userProfile, setUserProfile] = useState<{ name: string; location: string } | null>(null);
  const [queuePosition, setQueuePosition] = useState(1);
  const [queueTime, setQueueTime] = useState(30);
  const [sleepTime, setSleepTime] = useState(0);
  const [showEasterEgg, setShowEasterEgg] = useState(false);
  const [redeemCode, setRedeemCode] = useState('');

  // Advanced features state
  const [userStats, setUserStats] = useState<UserStats>({
    totalSessions: 0,
    totalSleepTime: 0,
    averageQuality: 0,
    longestSession: 0,
    weeklyGoal: 56, // 8 hours * 7 days
    weeklyProgress: 0
  });
  const [sleepHistory, setSleepHistory] = useState<SleepSession[]>([]);
  const [showStats, setShowStats] = useState(false);
  const [currentPing, setCurrentPing] = useState(15);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [sessionQuality, setSessionQuality] = useState(5);

  // Audio refs
  const audioContextRef = useRef<AudioContext | null>(null);

  // Mock sleepers data
  const sleepers = ['@nachteule', '@bettschwere', '@träumerlein'];

  // Extended server locations with realistic data
  const serverLocations: ServerLocation[] = [
    // Germany
    { value: 'Berlin', label: 'DE: Berlin', country: 'Deutschland', continent: 'Europa', coordinates: [52.52, 13.405], load: 67 },
    { value: 'München', label: 'DE: München', country: 'Deutschland', continent: 'Europa', coordinates: [48.1351, 11.582], load: 45 },
    { value: 'Hamburg', label: 'DE: Hamburg', country: 'Deutschland', continent: 'Europa', coordinates: [53.5511, 9.9937], load: 72 },
    { value: 'Frankfurt', label: 'DE: Frankfurt', country: 'Deutschland', continent: 'Europa', coordinates: [50.1109, 8.6821], load: 38 },
    { value: 'Leipzig', label: 'DE: Leipzig', country: 'Deutschland', continent: 'Europa', coordinates: [51.3397, 12.3731], load: 55 },
    { value: 'Köln', label: 'DE: Köln', country: 'Deutschland', continent: 'Europa', coordinates: [50.9375, 6.9603], load: 63 },

    // Europe
    { value: 'Amsterdam', label: 'NL: Amsterdam', country: 'Niederlande', continent: 'Europa', coordinates: [52.3676, 4.9041], load: 42 },
    { value: 'Paris', label: 'FR: Paris', country: 'Frankreich', continent: 'Europa', coordinates: [48.8566, 2.3522], load: 78 },
    { value: 'London', label: 'UK: London', country: 'Vereinigtes Königreich', continent: 'Europa', coordinates: [51.5074, -0.1278], load: 85 },
    { value: 'Zürich', label: 'CH: Zürich', country: 'Schweiz', continent: 'Europa', coordinates: [47.3769, 8.5417], load: 34 },
    { value: 'Wien', label: 'AT: Wien', country: 'Österreich', continent: 'Europa', coordinates: [48.2082, 16.3738], load: 51 },
    { value: 'Stockholm', label: 'SE: Stockholm', country: 'Schweden', continent: 'Europa', coordinates: [59.3293, 18.0686], load: 29 },

    // North America
    { value: 'NewYork', label: 'US: New York', country: 'USA', continent: 'Nordamerika', coordinates: [40.7128, -74.006], load: 92 },
    { value: 'LosAngeles', label: 'US: Los Angeles', country: 'USA', continent: 'Nordamerika', coordinates: [34.0522, -118.2437], load: 88 },
    { value: 'Toronto', label: 'CA: Toronto', country: 'Kanada', continent: 'Nordamerika', coordinates: [43.6532, -79.3832], load: 76 },

    // Asia-Pacific
    { value: 'Tokyo', label: 'JP: Tokyo', country: 'Japan', continent: 'Asien', coordinates: [35.6762, 139.6503], load: 95 },
    { value: 'Singapore', label: 'SG: Singapore', country: 'Singapur', continent: 'Asien', coordinates: [1.3521, 103.8198], load: 73 },
    { value: 'Sydney', label: 'AU: Sydney', country: 'Australien', continent: 'Ozeanien', coordinates: [-33.8688, 151.2093], load: 56 }
  ];

  // Calculate realistic ping based on distance
  const calculatePing = useCallback((serverLocation: string, userLocation = 'Berlin') => {
    const server = serverLocations.find(loc => loc.value === serverLocation);
    const user = serverLocations.find(loc => loc.value === userLocation);

    if (!server || !user) return 15;

    // Calculate distance using Haversine formula (simplified)
    const R = 6371; // Earth's radius in km
    const dLat = (server.coordinates[0] - user.coordinates[0]) * Math.PI / 180;
    const dLon = (server.coordinates[1] - user.coordinates[1]) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(user.coordinates[0] * Math.PI / 180) * Math.cos(server.coordinates[0] * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;

    // Rough ping calculation: ~0.1ms per 10km + base latency
    const basePing = 5;
    const distancePing = Math.round(distance / 10 * 0.1);
    const networkVariation = Math.random() * 10; // Random network variation

    return Math.max(1, Math.round(basePing + distancePing + networkVariation));
  }, [serverLocations]);

  // Sound effects
  const playSound = useCallback((type: 'click' | 'success' | 'notification' | 'ambient') => {
    if (!soundEnabled || !audioContextRef.current) return;

    const audioContext = audioContextRef.current;
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    switch (type) {
      case 'click':
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1);
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.1);
        break;
      case 'success':
        oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
        oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1); // E5
        oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime + 0.2); // G5
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.3);
        break;
      case 'notification':
        oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
        gainNode.gain.setValueAtTime(0.05, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.2);
        break;
    }
  }, [soundEnabled]);

  // Initialize audio context
  useEffect(() => {
    const initAudio = () => {
      try {
        // @ts-expect-error - webkitAudioContext is not in standard types
        audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      } catch (error) {
        console.log('Audio not supported');
      }
    };

    initAudio();
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  // Load data from localStorage
  useEffect(() => {
    const savedProfile = localStorage.getItem('schlafserver-profile');
    const savedStats = localStorage.getItem('schlafserver-stats');
    const savedHistory = localStorage.getItem('schlafserver-history');
    const savedSettings = localStorage.getItem('schlafserver-settings');

    if (savedProfile) {
      const profile = JSON.parse(savedProfile);
      setUserProfile(profile);
      setUsername(profile.name);
      setSelectedLocation(profile.location);
    }

    if (savedStats) {
      setUserStats(JSON.parse(savedStats));
    }

    if (savedHistory) {
      setSleepHistory(JSON.parse(savedHistory));
    }

    if (savedSettings) {
      const settings = JSON.parse(savedSettings);
      setSoundEnabled(settings.soundEnabled ?? true);
    }
  }, []);

  // Save to localStorage
  const saveToStorage = useCallback(() => {
    if (userProfile) {
      localStorage.setItem('schlafserver-profile', JSON.stringify(userProfile));
    }
    localStorage.setItem('schlafserver-stats', JSON.stringify(userStats));
    localStorage.setItem('schlafserver-history', JSON.stringify(sleepHistory));
    localStorage.setItem('schlafserver-settings', JSON.stringify({ soundEnabled }));
  }, [userProfile, userStats, sleepHistory, soundEnabled]);

  // Update current time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('de-DE', {
        hour: '2-digit',
        minute: '2-digit'
      }));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Update ping based on selected location
  useEffect(() => {
    setCurrentPing(calculatePing(selectedLocation));
    const interval = setInterval(() => {
      setCurrentPing(calculatePing(selectedLocation) + Math.round(Math.random() * 5 - 2.5));
    }, 5000);
    return () => clearInterval(interval);
  }, [selectedLocation, calculatePing]);

  // Queue timer
  useEffect(() => {
    if (currentScreen === 'queue' && queueTime > 0) {
      const interval = setInterval(() => {
        setQueueTime(prev => {
          if (prev <= 1) {
            playSound('success');
            transitionToScreen('server');
            setSleepTime(0);
            return 0;
          }
          if (prev === 5) {
            playSound('notification');
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [currentScreen, queueTime, playSound]);

  // Sleep timer
  useEffect(() => {
    if (currentScreen === 'server') {
      const interval = setInterval(() => {
        setSleepTime(prev => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [currentScreen]);

  // Auto-save every 30 seconds
  useEffect(() => {
    const interval = setInterval(saveToStorage, 30000);
    return () => clearInterval(interval);
  }, [saveToStorage]);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatQueueTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  // Screen transition with animation
  const transitionToScreen = (screen: string) => {
    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentScreen(screen);
      setIsTransitioning(false);
    }, 300);
  };

  const handleJoinServer = () => {
    playSound('click');
    transitionToScreen('setup');
  };

  const handleSaveProfile = () => {
    if (username.trim()) {
      playSound('success');
      const profile = { name: username.trim(), location: selectedLocation };
      setUserProfile(profile);
      saveToStorage();
      transitionToScreen('queue');
      setQueueTime(30);
    }
  };

  const handleLeaveQueue = () => {
    playSound('click');
    transitionToScreen('main');
    setQueueTime(30);
  };

  const handleLeaveServer = () => {
    playSound('click');

    // Save sleep session
    if (sleepTime > 60) { // Only save if slept for more than 1 minute
      const session: SleepSession = {
        date: new Date().toISOString().split('T')[0],
        duration: sleepTime,
        quality: sessionQuality,
        location: userProfile?.location || selectedLocation
      };

      const newHistory = [...sleepHistory, session];
      setSleepHistory(newHistory);

      // Update stats
      const newStats = {
        ...userStats,
        totalSessions: userStats.totalSessions + 1,
        totalSleepTime: userStats.totalSleepTime + sleepTime,
        averageQuality: newHistory.reduce((acc, s) => acc + s.quality, 0) / newHistory.length,
        longestSession: Math.max(userStats.longestSession, sleepTime),
        weeklyProgress: userStats.weeklyProgress + (sleepTime / 3600)
      };
      setUserStats(newStats);
    }

    transitionToScreen('main');
    setSleepTime(0);
  };

  const handleKickSleeper = (sleeperName: string) => {
    playSound('click');
    console.log(`Kicked ${sleeperName}`);
  };

  const handleRedeemCode = () => {
    if (redeemCode.trim()) {
      playSound('success');
      console.log(`Redeeming code: ${redeemCode}`);
      setRedeemCode('');
    }
  };

  const handleEasterEgg = () => {
    playSound('notification');
    setShowEasterEgg(true);
    setTimeout(() => setShowEasterEgg(false), 3000);
  };

  const getServerLoad = (location: string) => {
    return serverLocations.find(loc => loc.value === location)?.load || 50;
  };

  const getWeeklyGoalProgress = () => {
    return Math.min(100, (userStats.weeklyProgress / userStats.weeklyGoal) * 100);
  };

  return (
    <div className={`min-h-screen transition-opacity duration-300 ${isTransitioning ? 'opacity-50' : 'opacity-100'}`}>
      {/* Main landing page */}
      {currentScreen === 'main' && (
        <div className="container animate-fade-in">
          <header>
            <div className="logo">💤 Schlafserver</div>
            <div className="flex items-center gap-4">
              <button
                className="text-xl hover:scale-110 transition-transform cursor-pointer"
                onClick={() => setShowStats(!showStats)}
                title="Statistiken anzeigen"
              >
                📊
              </button>
              <button
                className={`text-xl hover:scale-110 transition-transform cursor-pointer ${soundEnabled ? '' : 'opacity-50'}`}
                onClick={() => {
                  setSoundEnabled(!soundEnabled);
                  playSound('click');
                }}
                title="Sound ein/aus"
              >
                {soundEnabled ? '🔊' : '🔇'}
              </button>
              <div className="cursor-pointer hover:scale-110 transition-transform" onClick={handleEasterEgg}>🌙</div>
              <div className="current-time">{currentTime}</div>
            </div>
          </header>

          <div className="hero">
            <h1 className="animate-slide-up">Verbessere deinen Schlaf</h1>
            <div className="sleepers-count animate-slide-up animation-delay-100">
              Aktive Schläfer: <span className="animate-pulse">{activeSleepers}</span>
            </div>
            <p className="subtitle animate-slide-up animation-delay-200">
              Trete einer Gemeinschaft von Schläfern bei und verbessere deine Schlafqualität.
              Unser intelligenter Server begleitet dich durch deine Schlafenszeit.
            </p>

            <button
              className="btn btn-lg animate-slide-up animation-delay-300 hover:scale-105 transition-all"
              onClick={handleJoinServer}
            >
              Jetzt beitreten
              <span className="animate-bounce-x">→</span>
            </button>
          </div>

          {/* Stats Panel */}
          {showStats && userStats.totalSessions > 0 && (
            <div className="stats-panel animate-slide-down">
              <div className="stats-header">
                <h3>📊 Deine Schlaf-Statistiken</h3>
                <button onClick={() => setShowStats(false)} className="close-btn">✕</button>
              </div>
              <div className="stats-grid">
                <div className="stat-card">
                  <div className="stat-value">{userStats.totalSessions}</div>
                  <div className="stat-label">Gesamt Sessions</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">{formatDuration(userStats.totalSleepTime)}</div>
                  <div className="stat-label">Gesamte Schlafzeit</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">{userStats.averageQuality.toFixed(1)}⭐</div>
                  <div className="stat-label">Ø Qualität</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">{formatDuration(userStats.longestSession)}</div>
                  <div className="stat-label">Längste Session</div>
                </div>
              </div>
              <div className="weekly-progress">
                <div className="progress-header">
                  <span>Wochenziel: {userStats.weeklyGoal}h</span>
                  <span>{userStats.weeklyProgress.toFixed(1)}h / {userStats.weeklyGoal}h</span>
                </div>
                <div className="progress-bar">
                  <div
                    className="progress-fill"
                    style={{ width: `${getWeeklyGoalProgress()}%` }}
                  />
                </div>
              </div>
            </div>
          )}

          <div className="sleepers-list animate-slide-up animation-delay-400">
            <div className="sleepers-title">
              <span>😴 Aktive Schläfer</span>
            </div>
            <div>
              {sleepers.map((sleeper) => (
                <div key={sleeper} className="sleeper-item hover:bg-white/10 transition-colors">
                  <div className="sleeper-name">{sleeper}</div>
                  <button
                    className="kick-btn hover:scale-110 transition-transform"
                    onClick={() => handleKickSleeper(sleeper)}
                  >
                    🦶
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="redeem-container animate-slide-up animation-delay-500">
            <div className="redeem-title">
              <span>🎁 Code einlösen</span>
            </div>
            <div className="redeem-form">
              <input
                type="text"
                placeholder="Premium-Code eingeben..."
                value={redeemCode}
                onChange={(e) => setRedeemCode(e.target.value)}
                className="flex-1 px-3 py-2 bg-white/5 border border-white/20 rounded-lg text-white transition-all focus:border-purple-400 focus:bg-white/10"
              />
              <button className="btn hover:scale-105 transition-transform" onClick={handleRedeemCode}>
                Einlösen
              </button>
            </div>
          </div>

          <div className="features-grid">
            {[
              { icon: '⏱️', title: 'Schneller Eintritt', desc: 'Mit Premium-Codes sofort Zugang erhalten, ansonsten faire Warteschlange.' },
              { icon: '🌍', title: 'Globale Server', desc: 'Wähle aus mehreren Standorten weltweit für optimalen Ping.' },
              { icon: '📊', title: 'Schlaf-Analyse', desc: 'Detaillierte Statistiken zu deinem Schlafverhalten und -qualität.' },
              { icon: '👥', title: 'Community', desc: 'Verbinde dich mit Gleichgesinnten für bessere Schlafgewohnheiten.' }
            ].map((feature, index) => (
              <div key={feature.title} className={`feature-card hover:scale-105 transition-all animate-slide-up animation-delay-${600 + index * 100}`}>
                <div className="feature-icon">{feature.icon}</div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-desc">{feature.desc}</p>
                {feature.title === 'Community' && (
                  <a
                    href="https://discord.gg/vrweyBXXyC"
                    className="discord-link hover:scale-105 transition-transform"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Unserem Discord beitreten →
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Setup Screen */}
      {currentScreen === 'setup' && (
        <div className="app-screen active">
          <div className="screen-container animate-fade-in">
            <div className="screen-header">
              <h2 className="screen-title animate-slide-down">Dein Profil</h2>
              <p className="screen-subtitle animate-slide-down animation-delay-100">Erstelle dein persönliches Schlafprofil</p>
            </div>

            <div className="form-group animate-slide-up animation-delay-200">
              <label htmlFor="username">Benutzername</label>
              <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Dein Benutzername"
                className="transition-all focus:scale-105"
              />
            </div>

            <div className="form-group animate-slide-up animation-delay-300">
              <label htmlFor="location">Server-Standort</label>
              <select
                id="location"
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="transition-all focus:scale-105"
              >
                {serverLocations.map((location) => (
                  <option key={location.value} value={location.value}>
                    {location.label} (Ping: ~{calculatePing(location.value)}ms, Load: {location.load}%)
                  </option>
                ))}
              </select>
            </div>

            <button
              className="btn animate-slide-up animation-delay-400 hover:scale-105 transition-all"
              onClick={handleSaveProfile}
            >
              Speichern & fortfahren
            </button>
          </div>
        </div>
      )}

      {/* Queue Screen */}
      {currentScreen === 'queue' && userProfile && (
        <div className="app-screen active">
          <div className="screen-container animate-fade-in">
            <div className="user-profile animate-slide-down">
              <div className="avatar animate-bounce">{userProfile.name.charAt(0).toUpperCase()}</div>
              <div className="user-info">
                <div className="user-name">{userProfile.name}</div>
                <div className="user-location">
                  <span>{serverLocations.find(loc => loc.value === userProfile.location)?.country}: {userProfile.location}</span>
                </div>
              </div>
            </div>

            <div className="screen-header animate-slide-down animation-delay-100">
              <h2 className="screen-title">Warteschlange</h2>
              <p className="screen-subtitle">Du bist in der Warteschlange für den Schlafserver</p>
            </div>

            <div className={`timer-display animate-pulse ${queueTime <= 5 ? 'text-red-400' : ''}`}>
              {formatQueueTime(queueTime)}
            </div>

            <div className="queue-info animate-slide-up animation-delay-200">
              <div className="queue-item">
                <span className="queue-label">Deine Position:</span>
                <span className="queue-value">{queuePosition}</span>
              </div>
              <div className="queue-item">
                <span className="queue-label">Warteschlangenlänge:</span>
                <span className="queue-value">15</span>
              </div>
              <div className="queue-item">
                <span className="queue-label">Geschätzte Wartezeit:</span>
                <span className="queue-value">~{queueTime}s</span>
              </div>
              <div className="queue-item">
                <span className="queue-label">Aktive Schläfer:</span>
                <span className="queue-value">{activeSleepers}</span>
              </div>
              <div className="queue-item">
                <span className="queue-label">Server-Load:</span>
                <span className="queue-value">{getServerLoad(userProfile.location)}%</span>
              </div>
            </div>

            <button
              className="btn btn-secondary animate-slide-up animation-delay-300 hover:scale-105 transition-all"
              onClick={handleLeaveQueue}
            >
              Warteschlange verlassen
            </button>
          </div>
        </div>
      )}

      {/* Server Screen */}
      {currentScreen === 'server' && userProfile && (
        <div className="app-screen active">
          <div className="screen-container animate-fade-in">
            <div className="user-profile animate-slide-down">
              <div className="avatar animate-pulse">{userProfile.name.charAt(0).toUpperCase()}</div>
              <div className="user-info">
                <div className="user-name">{userProfile.name}</div>
                <div className="user-location">
                  <span>{serverLocations.find(loc => loc.value === userProfile.location)?.country}: {userProfile.location}</span>
                </div>
              </div>
            </div>

            <div className="screen-header animate-slide-down animation-delay-100">
              <h2 className="screen-title">Gute Nacht</h2>
              <p className="screen-subtitle">Der Server begleitet dich durch deine Schlafenszeit</p>
            </div>

            <div className="sleep-timer animate-pulse">{formatTime(sleepTime)}</div>

            <div className="server-stats animate-slide-up animation-delay-200">
              <div className="stat-item">
                <span>Ping:</span>
                <span className={`stat-value ml-1 ${currentPing > 50 ? 'text-red-400' : currentPing > 25 ? 'text-yellow-400' : 'text-green-400'}`}>
                  {currentPing}
                </span>
                <span>ms</span>
              </div>
              <div className="stat-item">
                <span>Server:</span>
                <span className="stat-value ml-1">{userProfile.location}</span>
              </div>
              <div className="stat-item">
                <span>Aktive Nutzer:</span>
                <span className="stat-value ml-1">75</span>
              </div>
              <div className="stat-item">
                <span>Server-Load:</span>
                <span className={`stat-value ml-1 ${getServerLoad(userProfile.location) > 80 ? 'text-red-400' : 'text-green-400'}`}>
                  {getServerLoad(userProfile.location)}%
                </span>
              </div>
            </div>

            <div className="quality-selector animate-slide-up animation-delay-300">
              <label>Schlafqualität bewerten:</label>
              <div className="star-rating">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    className={`star ${star <= sessionQuality ? 'active' : ''} hover:scale-125 transition-transform`}
                    onClick={() => setSessionQuality(star)}
                  >
                    ⭐
                  </button>
                ))}
              </div>
            </div>

            <div className="sleepers-count animate-slide-up animation-delay-400">
              Aktuell schlafen: <span className="animate-pulse">{activeSleepers}</span> Personen
            </div>

            <button
              className="btn btn-secondary animate-slide-up animation-delay-500 hover:scale-105 transition-all"
              onClick={handleLeaveServer}
            >
              Aufgewacht? Server verlassen
            </button>
          </div>
        </div>
      )}

      {/* Easter Egg */}
      {showEasterEgg && (
        <div className="easter-egg active animate-bounce">
          <div className="easter-egg-text">Du hast das geheime Schaf gefunden</div>
          <div className="easter-egg-emoji animate-spin">🐑</div>
        </div>
      )}
    </div>
  );
}
